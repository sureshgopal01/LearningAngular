package com.itssglobal.sigma.dataintegrator.rest;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itssglobal.sigma.dataintegrator.domain.DataStore;
import com.itssglobal.sigma.dataintegrator.pojo.ColumnMetadata;
import com.itssglobal.sigma.dataintegrator.pojo.TableMetadata;
import com.itssglobal.sigma.dataintegrator.repository.DataStoreRepository;
import com.itssglobal.sigma.dataintegrator.service.DataSourceService;

import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.ZonedDateTime;
import java.util.Collection;
import java.util.List;

/**
 * Created by Anass on 14/06/2017.
 */
@Controller
@RequestMapping(value = "/api/v1/dataSource")
public class DataSourceController {

    @Autowired
    private DataSourceService dataSourceService;

    @Autowired
    private DataStoreRepository dataStoreRepository;

    @RequestMapping(value = "/home", method = RequestMethod.GET)
    public String homePage() {
        return "home";
    }

    @RequestMapping(value = "/creation", method = RequestMethod.GET)
    public String dataSourceCreation() {
        return "dataSource/creation";
    }

    @PostMapping("/testConnection")
    @ResponseBody
    public ObjectNode testDataSourceConnection(@RequestBody DataStore dataSource) throws JSONException {
        return dataSourceService.testDatabaseConnection(dataSource);
    }

    @RequestMapping(value = "/saveDataSource", method = RequestMethod.POST)
    public String saveDataSource(@RequestBody DataStore dataSource) throws JSONException {
    	System.out.println("Before Calling Save");
        dataStoreRepository.save(dataSource);
        System.out.println("After Calling Save");
        return "home";
    }

    @RequestMapping(value = "/editDataSource", method = RequestMethod.POST)
    public String editDataSource(@RequestParam Long id, @RequestBody DataStore dataSource) {
        DataStore ds = dataStoreRepository.findOne(id);
        ds.setName(dataSource.getName());
        ds.setUrl(dataSource.getUrl());
        ds.setUsername(dataSource.getUsername());
        ds.setPassword(dataSource.getPassword());
        ds.setDataSourceType(dataSource.getDataSourceType());
        ds.setDefaultPort(dataSource.getDefaultPort());
        ds.setLastModifiedDate(ZonedDateTime.now());
        dataStoreRepository.save(ds);
        return "home";
    }

    @RequestMapping(value = "/deleteDataSource/{id}", method = RequestMethod.DELETE)
    @ResponseBody
    public ObjectNode deleteDataSource(@PathVariable("id") Long id) {
    	System.out.println("Value of id=" + id);
    	
        return dataSourceService.removeDataSource(id);
//    	return null;
    }

    @GetMapping("/list")
    public String returnAllSources(Model model) {
        model.addAllAttributes(dataStoreRepository.findAll());
        return "dataSource/dataSources";
    }

/*    @GetMapping("/getAllSources")
    @ResponseBody
    public ObjectNode getAllSources() {
        return dataSourceService.getAllSources();
    }*/
    @GetMapping("/getAllSources")
    @ResponseBody
    public List<DataStore> getAllSources() {
        return dataSourceService.getAllDataSources1();
    }
    @GetMapping("/getAllDataSources")
    @ResponseBody
    public ObjectNode getAllDataSources() {
        return dataSourceService.getAllDataSources();
    }

    @GetMapping("/getDataSourceById")
    @ResponseBody
    public DataStore getDataSourceById(@RequestParam Long id) {
        return dataStoreRepository.findOne(id);
    }

    @GetMapping("/getDataSourceTables")
    @ResponseBody
    public Collection<TableMetadata> getDataSourceTables(@RequestParam Long id) {
        return dataSourceService.getTablesMetadata(dataStoreRepository.findOne(id));
    }

    @GetMapping("/getDataSourceTableColumns")
    @ResponseBody
    public Collection<ColumnMetadata> getDataSourceTableColumns(@RequestParam Long id, @RequestParam String tableName) {
        return dataSourceService.getColumnsForTable(dataStoreRepository.findOne(id), tableName);
    }
}
