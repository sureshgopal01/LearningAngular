package com.itssglobal.sigma.dataintegrator.config;

import com.itssglobal.sigma.dataintegrator.pojo.DataSourceMetadata;
import com.itssglobal.sigma.dataintegrator.pojo.JMSExchange;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Anass on 14/06/2017.
 */
@Configuration
//@EnableWebMvc
public class DataIntegratorConfiguration {

    @Bean(name = "DataSourceMetadataCache")
    public ConcurrentHashMap<Long, DataSourceMetadata> cache() {
        return new ConcurrentHashMap<Long, DataSourceMetadata>();
    }

    @Bean(name = "jmsRequestResponseCache")
    public ConcurrentHashMap<String, JMSExchange> jmsReqResCache() {
        return new ConcurrentHashMap<String, JMSExchange>();
    }
}
