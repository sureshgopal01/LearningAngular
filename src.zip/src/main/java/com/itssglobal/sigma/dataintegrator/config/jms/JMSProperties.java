package com.itssglobal.sigma.dataintegrator.config.jms;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by Anass on 31/05/2017.
 */
@ConfigurationProperties(prefix = "sigma.jms")
@Data
public class JMSProperties {

    private String taskInboundQueue;
    private String taskOutboundQueue;
}
