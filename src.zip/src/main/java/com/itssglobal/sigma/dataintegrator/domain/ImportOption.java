package com.itssglobal.sigma.dataintegrator.domain;

import lombok.Getter;

/**
 * Created by Anass on 11/07/2017.
 */
public enum ImportOption {
    INSERT("insert"), TRUNCATE_INSERT("truncate table"), DROP_INSERT("drop table");

    @Getter
    String value;

    ImportOption(String value) {
        this.value = value;
    }
}
