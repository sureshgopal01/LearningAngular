package com.itssglobal.sigma.dataintegrator.domain;

import com.itssglobal.sigma.dataintegrator.util.DataSourceUtils;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Created by Anass on 13/06/2017.
 */
@SuppressWarnings("serial")
@Entity(name = "SIGMA_DATA_SOURCE")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
public class DataStore extends AbstractAuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name")
    private String name;

    @Column(name = "url")
    private String url;

    @Column(name = "default_port")
    private int defaultPort;

    @Column(name = "username")
    private String username;

    @Column(name = "password")
    private String password;

    @Enumerated(EnumType.STRING)
    private DataSourceUtils.DataSourceType dataSourceType;
}
