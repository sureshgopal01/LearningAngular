package com.itssglobal.sigma.dataintegrator.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@SuppressWarnings("serial")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "SIGMA_MAPPING_FIELD")
public class Field extends BaseObject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @Column(name = "field_name")
    private String name;

    @Column(name = "field_type")
    private String type;

    @Column(name = "primary_key")
    private boolean primaryKey;

    @Column(name = "not_null")
    private boolean notNull;

    @Column(name = "unique_constraint")
    private boolean unique;

    @Column(name = "indexed")
    private boolean indexed;

    @Column(name = "field_table_name")
    private String table;

    @OneToOne
    @JoinColumn(name = "SIGMA_DATA_SOURCE")
    private DataStore dataSource;
}
