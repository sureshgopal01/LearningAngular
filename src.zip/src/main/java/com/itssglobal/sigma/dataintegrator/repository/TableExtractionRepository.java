package com.itssglobal.sigma.dataintegrator.repository;

import com.itssglobal.sigma.dataintegrator.domain.TableExtraction;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Anass on 15/06/2017.
 */
public interface TableExtractionRepository extends JpaRepository<TableExtraction, Long> {
}
