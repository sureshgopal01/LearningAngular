package com.itssglobal.sigma.dataintegrator.messaging;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * Created by mastermind on 10/06/2017 at 00:27.
 */
@AllArgsConstructor
public class TaskOutboundMessage<T> implements Serializable {

    @Getter
    @Setter
    private String id;

    @Getter
    @Setter
    private T taskResult;
}
