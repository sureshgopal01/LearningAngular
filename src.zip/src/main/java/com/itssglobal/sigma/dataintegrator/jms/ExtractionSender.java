package com.itssglobal.sigma.dataintegrator.jms;

import com.itssglobal.sigma.dataintegrator.domain.Extraction;
import com.itssglobal.sigma.dataintegrator.messaging.TaskInboundMessage;
import com.itssglobal.sigma.dataintegrator.pojo.JMSExchange;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.support.converter.MessageConverter;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Component;

import javax.jms.Message;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Anass on 15/06/2017.
 */
@Component
public class ExtractionSender {

    @Autowired
    MessageConverter messageConverter;

    private JmsTemplate jmsTemplate;

    @Autowired
    @Qualifier("jmsRequestResponseCache")
    private ConcurrentHashMap<String, JMSExchange> jmsRequestResponseCache;

    @Autowired
    public ExtractionSender(JmsTemplate jmsTemplate) {
        this.jmsTemplate = jmsTemplate;
    }

    @SendTo("${sigma.jms.task-inbound-queue}")
    public void sendExtraction(String destination, Extraction extraction) {
        jmsTemplate.send(destination, session -> {
            TaskInboundMessage taskInboundMessage = new TaskInboundMessage();
            String correlationID = UUID.randomUUID().toString();
            taskInboundMessage.setId(correlationID);
            taskInboundMessage.setPayload(extraction);
            taskInboundMessage.setTaskType("DATA_STAGING");
            JMSExchange jmsExchange = new JMSExchange();
            jmsExchange.setRequestObject(taskInboundMessage);
            Message extractionMessage = messageConverter.toMessage(taskInboundMessage, session);
            extractionMessage.setJMSCorrelationID(correlationID);
            jmsRequestResponseCache.put(extractionMessage.getJMSCorrelationID(), jmsExchange);
            return extractionMessage;
        });
    }
}
