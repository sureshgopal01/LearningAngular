package com.itssglobal.sigma.dataintegrator.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anass on 18/05/2017.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TableMetadata {

    private String name;

    private String schema;

    private List<ColumnMetadata> columns = new ArrayList<>();

    private TableMetadata(Builder builder) {
        setName(builder.name);
        setSchema(builder.schema);
        setColumns(builder.columns);
    }

    public static Builder newBuilder() {
        return new Builder();
    }

    public static final class Builder {
        private String name;
        private String schema;
        private List<ColumnMetadata> columns = new ArrayList<>();

        private Builder() {
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withSchema(String schema) {
            this.schema = schema;
            return this;
        }

        public Builder withColumn(String name, String type, boolean isPrimaryKey, boolean isUnique, boolean isNullable,
                                  boolean isIndexed) {
            this.columns.add(new ColumnMetadata(name, type, isPrimaryKey, isUnique, isNullable, isIndexed));
            return this;
        }

        public TableMetadata build() {
            return new TableMetadata(this);
        }
    }
}
