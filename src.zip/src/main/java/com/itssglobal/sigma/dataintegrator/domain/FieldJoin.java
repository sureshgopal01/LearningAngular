package com.itssglobal.sigma.dataintegrator.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Created by Anass on 16/05/2017.
 */
@SuppressWarnings("serial")
@Entity(name = "SIGMA_FIELD_JOIN")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
public class FieldJoin extends BaseObject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    private Field leftField;

    @OneToOne(cascade = CascadeType.ALL)
    private Field rightField;

    @Enumerated(EnumType.STRING)
    private JoinType type;
}
