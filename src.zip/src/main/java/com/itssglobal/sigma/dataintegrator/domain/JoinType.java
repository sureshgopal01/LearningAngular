package com.itssglobal.sigma.dataintegrator.domain;

import lombok.Getter;

/**
 * Created by Anass on 16/05/2017.
 */
public enum JoinType {
    INNER_JOIN("inner join"), LEFT_JOIN("left join"), UNION_ALL("union all");

    @Getter
    String name;


    JoinType(String name) {
        this.name = name;
    }
}
