package com.itssglobal.sigma.dataintegrator.domain;

/**
 * Created by mastermind on 20/05/2017 at 20:58.
 */
public enum FormulaType {
    UPPERCASE, LOWERCASE, CONCATENATE
}
