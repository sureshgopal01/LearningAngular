package com.itssglobal.sigma.dataintegrator.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Anass on 15/06/2017.
 */
@SuppressWarnings("serial")
@Entity(name = "SIGMA_TABLE_EXTRACTION")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
public class TableExtraction extends AbstractAuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @OneToMany(cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<FieldMapping> mappingList;

    @OneToMany(cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<FieldFilter> filters;

    @OneToMany(cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<FieldJoin> joins;

    @Column(name = "create_table")
    private boolean create_table;

    @Enumerated(EnumType.STRING)
    private ImportOption importOption;

    @Column(name = "table_name")
    private String tableName;

    @Column(name = "flowChartData", columnDefinition = "TEXT")
    private String flowChartData;

    @Column(name = "tableExtraction_scheduler")
    private TaskScheduler taskScheduler;
}
