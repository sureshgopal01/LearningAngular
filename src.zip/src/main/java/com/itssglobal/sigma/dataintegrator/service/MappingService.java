package com.itssglobal.sigma.dataintegrator.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itssglobal.sigma.dataintegrator.config.jms.JMSProperties;
import com.itssglobal.sigma.dataintegrator.domain.Extraction;
import com.itssglobal.sigma.dataintegrator.domain.TableExtraction;
import com.itssglobal.sigma.dataintegrator.domain.TaskScheduler;
import com.itssglobal.sigma.dataintegrator.domain.TaskTriggerPeriod;
import com.itssglobal.sigma.dataintegrator.jms.ExtractionSender;
import com.itssglobal.sigma.dataintegrator.repository.ExtractionRepository;
import com.itssglobal.sigma.dataintegrator.repository.TableExtractionRepository;
import com.itssglobal.sigma.dataintegrator.util.Constants;
import com.itssglobal.sigma.dataintegrator.util.JsonUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.List;

/**
 * Created by Anass on 07/07/2017.
 */
@Service
public class MappingService {

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private TableExtractionRepository tableExtractionRepository;

    @Autowired
    private ExtractionRepository extractionRepository;

    @Autowired
    private JMSProperties props;

    @Autowired
    private ExtractionSender extractionSender;

    private static String generateCronExpression(final String seconds, final String minutes, final String hours,
                                                 final String dayOfMonth,
                                                 final String month, final String dayOfWeek, final String year) {
        return String.format("%1$s %2$s %3$s %4$s %5$s %6$s %7$s", seconds, minutes, hours, dayOfMonth, month, dayOfWeek, year);
    }

    public ObjectNode getAllExtractions() {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        ArrayNode arrayNode = objectMapper.createArrayNode();
        List<Extraction> extractions = extractionRepository.findAll();
        for (Extraction extraction : extractions) {
            for (TableExtraction tableExtraction : extraction.getTableExtractions()) {
                ArrayNode dataSourceObject = objectMapper.createArrayNode();
                dataSourceObject.add(tableExtraction.getId());
                dataSourceObject.add(tableExtraction.getTableName());
                dataSourceObject.add(tableExtraction.isCreate_table());
                dataSourceObject.add(tableExtraction.getImportOption().getValue());
                dataSourceObject.add(tableExtraction.getCreatedDate().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
                dataSourceObject.add(tableExtraction.getId());
                dataSourceObject.add(extraction.getName());
                arrayNode.add(dataSourceObject);
            }
        }
        jsonObject.put("tableExtractions", arrayNode);
        return jsonObject;
    }

    public ObjectNode getTaskTriggerPeriods() {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        ArrayNode arrayNode = objectMapper.createArrayNode();
        for (TaskTriggerPeriod period : TaskTriggerPeriod.values()) {
            arrayNode.add(period.toString());
        }
        jsonObject.put("taskTriggerPeriods", arrayNode);
        return jsonObject;
    }

    public ObjectNode setTaskSchedulerCron(Long id, TaskScheduler taskScheduler) {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        System.out.println("Task Scheduler : \t DATE : --->\t" + taskScheduler.getDate() + "\t PERIOD : --->\t" + taskScheduler.getTaskTriggerPeriod().name());
        String cronExpr = "";
        switch (taskScheduler.getTaskTriggerPeriod()) {
            case WEEKLY:
                cronExpr = timeParser(taskScheduler.getDate(), taskScheduler.getTaskTriggerPeriod());
                System.out.println(cronExpr);
                break;
            case MONTHLY:
                cronExpr = dateAndTimeParser(taskScheduler.getDate(), taskScheduler.getTaskTriggerPeriod());
                System.out.println(cronExpr);
                break;
            case ONLY_ONCE:
                cronExpr = dateAndTimeParser(taskScheduler.getDate(), taskScheduler.getTaskTriggerPeriod());
                System.out.println(cronExpr);
                break;
            case IMMEDIATELY:
                cronExpr = dateAndTimeParser(taskScheduler.getDate(), taskScheduler.getTaskTriggerPeriod());
                System.out.println(cronExpr);
                break;
            case PERIODICALLY:
                cronExpr = timeParser(taskScheduler.getDate(), taskScheduler.getTaskTriggerPeriod());
                System.out.println(cronExpr);
                break;
        }
        if (cronExpr.equals("ParseException"))
            jsonObject.put("error", "Can't parse given date/time !");
        else {
            tableExtractionRepository.findOne(id).setTaskScheduler(taskScheduler);
            for (Extraction extraction :
                    extractionRepository.findAll()) {
                for (TableExtraction tableExt : extraction.getTableExtractions()) {
                    if (tableExt.getId() == tableExtractionRepository.findOne(id).getId()) {
                        System.out.println(JsonUtils.toJson(extraction));
                        extractionSender.sendExtraction(props.getTaskInboundQueue(), extraction);
                    }
                }
            }
            //ToDo : send table extraction to task-runtime
            jsonObject.put("success", "Successfully added !");
        }
        return jsonObject;
    }

    public String timeParser(String taskSchedulerTime, TaskTriggerPeriod period) {
        switch (period) {
            case PERIODICALLY:
                if (taskSchedulerTime.split(":").length != 3)
                    return "ParseException";
                else
                    return generateCronExpression(taskSchedulerTime.split(":")[2], taskSchedulerTime.split(":")[1],
                            taskSchedulerTime.split(":")[0], "?", "*", "*", "*");
            case WEEKLY:
                if (taskSchedulerTime.split(Constants.SPACE).length != 2)
                    return "ParseException";
                else {
                    String time = taskSchedulerTime.split(Constants.SPACE)[0];
                    String days = taskSchedulerTime.split(Constants.SPACE)[1];
                    if (time.split(":").length != 3)
                        return "ParseException";
                    else
                        return generateCronExpression(time.split(":")[2], time.split(":")[1],
                                time.split(":")[0], "?", "*", days, "*");
                }
            default:
                return "ParseException";
        }
    }

    public String dateAndTimeParser(String taskSchedulerDateAndTime, TaskTriggerPeriod period) {
        if (taskSchedulerDateAndTime.split(Constants.SPACE).length != 2)
            return "ParseException";
        else {
            String taskSchedulerDate = taskSchedulerDateAndTime.split(Constants.SPACE)[0];
            String taskSchedulerTime = taskSchedulerDateAndTime.split(Constants.SPACE)[1];
            switch (period) {
                case MONTHLY:
                    return generateCronExpression(taskSchedulerTime.split(":")[2], taskSchedulerTime.split(":")[1],
                            taskSchedulerTime.split(":")[0], taskSchedulerDate.split("/")[0], "*", "?",
                            "*");
                case WEEKLY:
                    return generateCronExpression(taskSchedulerTime.split(":")[2], taskSchedulerTime.split(":")[1],
                            taskSchedulerTime.split(":")[0], taskSchedulerDate.split("/")[0], taskSchedulerDate.split("/")[1], "?",
                            taskSchedulerDate.split("/")[2]);
                case IMMEDIATELY:
                    //ToDo RUN JOB DIRECTLY
                    return generateCronExpression(taskSchedulerTime.split(":")[2], taskSchedulerTime.split(":")[1],
                            taskSchedulerTime.split(":")[0], taskSchedulerDate.split("/")[0], taskSchedulerDate.split("/")[1], "?",
                            taskSchedulerDate.split("/")[2]);
                default:
                    return generateCronExpression(taskSchedulerTime.split(":")[2], taskSchedulerTime.split(":")[1],
                            taskSchedulerTime.split(":")[0], taskSchedulerDate.split("/")[0], taskSchedulerDate.split("/")[1], "?",
                            taskSchedulerDate.split("/")[2]);
            }
        }
    }
}
