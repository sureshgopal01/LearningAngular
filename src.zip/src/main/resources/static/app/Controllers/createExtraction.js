var dialog, srcField, fired;

function hideFiltersModal() {
    dialog.modal('hide');
}

function showJoinModal() {
    $('#dataSourceJoinModal').modal('show');
    fired = true;
}

function deleteSelectedElement() {
    $('#flowChartDiv').flowchart('deleteSelected');
}

app.run(function ($rootScope, $http) {
    var res = $http.get('/api/v1/dataSource/getAllDataSources');
    res.then(function successCallback(data) {
        $rootScope.connections = data.data.dataSources;
    });

    res = $http.get('/getJoinTypes');
    res.then(function successCallback(data) {
        $rootScope.joinTypes = data.data;
    });
});

app.controller("extractionController", function ($scope, $http, $localStorage, $state, $compile) {

    editDataSourceMode = false;

    $("#tables1").select2({maximumSelectionLength: 1});
    $("#tables1Columns").select2();
    $("#tables2").select2({maximumSelectionLength: 1});
    $("#tables2Columns").select2();
    $scope.tables1Columns = [];
    $scope.tables2Columns = [];
    var operatorI = 0;
    $scope.showFlowChartDiv = true;
    $scope.showTablesDiv = false;
    $scope.linkData;

    if (editExtractionMode) {
        var res = $http.get('/api/v1/extraction/getExtractionById?id=' + extractionId);
        res.then(function successCallback(data) {
            $scope.extraction = data.data;
            $scope.mappingName = extractionName;
            $scope.joins = $scope.extraction.joins;
            $scope.filters = $scope.extraction.filters;
            $scope.importOption = $scope.extraction.importOption;
            $scope.TableAndColumns = [];
            $scope.columnTables1 = [];
            $scope.tables1Columns = [];
            $scope.columnTables1[0] = [];
            $scope.tableNameSelected1Columns = [];
            $scope.tableNameSelected1 = [];
            $scope.checked = 0;
            $scope.flag = false;
            $scope.tableNameSelected2 = [];

            if ($scope.extraction.create_table) {
                $scope.checkBoxModel = true;
                angular.forEach($scope.extraction.mappingList, function (value, index) {
                    $scope.TableAndColumns.push($scope.extraction.mappingList[index].inFields[0]);
                    $scope.columnTables1[0].push($scope.extraction.mappingList[index].inFields[0]);
                    // $scope.tables1Columns.push($scope.extraction.mappingList[index].inFields[0]);
                    // $scope.tableNameSelected1Columns.push($scope.extraction.mappingList[index].inFields[0].name);
                });
                $scope.newtableName = $scope.extraction.mappingList[0].outField.table;

                angular.forEach($scope.connections, function (item) {
                    if (angular.equals($scope.extraction.mappingList[0].inFields[0].dataSource, item)) {
                        $scope.tableNameSelected1[0] = $scope.extraction.mappingList[0].inFields[0].table;
                        $scope.connectionNameSelected1 = item;
                    }
                    if (angular.equals($scope.TableAndColumns[0].dataSource, item))
                        $scope.connectionNameSelected2 = item;
                });

                $scope.showFlowChartDiv = false;
                $scope.showTablesDiv = true;

                $scope.checked = 1;
                $scope.buttonPlus1clicked = 1;
                $scope.columnFromTables1Clicked = 1;
            }
            else {
                $scope.relations = $scope.extraction.mappingList;
                $scope.checked = 0;
                $scope.checkBoxModel = false;

                angular.forEach($scope.connections, function (item) {
                    if (angular.equals($scope.relations[0].inFields[0].dataSource, item))
                        $scope.connectionNameSelected1 = item;
                    if (angular.equals($scope.relations[0].outField.dataSource, item))
                        $scope.connectionNameSelected2 = item;
                });

                angular.forEach($scope.relations, function (item) {
                    $scope.TableAndColumns.push(item.inFields[0]);
                    $scope.tableNameSelected2[0] = item.outField.table;
                });

                $scope.showFlowChartDiv = true;
                $scope.showTablesDiv = false;

                //TODO SET DAT TO FLOWCHART
                var data = JSON.parse($scope.extraction.flowChartData);
                $('#flowChartDiv').flowchart('setData', data);
            }

            $scope.selectDataSource1();
            $scope.selectDataSource2();

            // $("#tables2").val($scope.relations[0].outField.table).trigger("change");

            var element = angular.element(document.querySelector('#extractionDiv'));

            $compile(element.contents())($scope);

            $scope.disableSources = true;
            $scope.disableDestination = true;
            swal.close();
        });
    }
    else {
        $scope.importOption = "INSERT";
        $scope.checked = 0;
        $scope.checkBoxModel = false;
        $scope.disableSources = false;
        $scope.disableDestination = false;
        $scope.relations = [];
        $scope.joins = [];
        $scope.TableAndColumns = [];
        $scope.filters = [];
        $scope.mappingName = "";
        $scope.joins = [];
        $scope.filters = [];
        $scope.columnsTableLength = 0;
        $scope.buttonPlus1clicked = 0;
        $scope.columnFromTables1Clicked = 0;
        $scope.columnTables2_2 = [];
        $scope.TableAndColumns = [];
        $scope.flag = false;

    }

    $("#joinTypesSelect").select2();
    $("#leftTables").select2();
    $("#leftTableColumns").select2();
    $("#rightTables").select2();
    $("#rightTableColumns").select2();

    var allDataSources = new Map();
    var vm = this;

    $scope.dataSource1_isChosen = 0;
    $scope.dataSource2_isChosen = 0;

    $scope.selectDataSource1 = function () {
        $scope.tables1 = 0;
        $scope.dataSource1_isChosen = 1;
        $scope.tables1 = [];

        if (allDataSources.get($scope.connectionNameSelected1.id))
            $scope.tables1 = allDataSources.get($scope.connectionNameSelected1.id);
        else {
            var res = $http.get('/api/v1/dataSource/getDataSourceTables?id=' + $scope.connectionNameSelected1.id);
            res.then(function successCallback(data) {
                for (var j = 0; j < data.data.length; j++) {
                    $scope.tables1.push(data.data[j]);
                    // if(editExtractionMode && angular.equals($scope.tableNameSelected1[0], data.data[j].name))
                    //     $scope.tables1Columns = data.data[j].columns;
                }
                allDataSources.set($scope.connectionNameSelected1.id, $scope.tables1);
            });
        }

        if (!editExtractionMode) {
            $scope.tableNameSelected1 = 0;
            $scope.columnTables1 = 0;
            $scope.columnFromTables1Clicked = 0;
            $scope.buttonPlus1clicked = 0;
            $scope.column1 = undefined;
            $scope.table1 = undefined;
            $scope.tables1Columns = [];
        }

        vm.tables1 = $scope.tables1;

        $scope.leftFieldDataSource = $scope.connectionNameSelected1;
        $scope.rightFieldDataSource = $scope.connectionNameSelected1;
    };

    $scope.tablesChanged1 = function () {
        $scope.buttonPlus1clicked = 0;
        $scope.column1 = undefined;
        $scope.table1 = undefined;
        $scope.tables1Columns = [];

        // $scope.tables1Columns
        angular.forEach($scope.tables1, function (item) {
            if (angular.equals(item.name, $scope.tableNameSelected1[0]))
                $scope.tables1Columns = item.columns;
        });
    };

    $scope.nbrTables1 = 0;
    $scope.showColumnsFromTables1 = function () {
        $scope.buttonPlus1clicked = 1;
        $scope.nbrTables1 = $scope.tableNameSelected1.length;
        $scope.columnTables1 = [];

        // GET ALL COLUMNS
        angular.forEach($scope.tableNameSelected1, function (value, index) {
            angular.forEach($scope.tables1, function (item) {
                if (angular.equals(item.name, $scope.tableNameSelected1[index]))
                    $scope.columnTables1.push(item.columns);
            });
        });

        $scope.columnTables1_temp = [];

        // GET ONLY SELECTED COLUMNS
        angular.forEach($scope.columnTables1[0], function (value) {
            angular.forEach($scope.tableNameSelected1Columns, function (item) {
                if (angular.equals(item, value.name))
                    $scope.columnTables1_temp.push(value);
            });
        });

        $scope.columnTables1[0] = $scope.columnTables1_temp;

        var columns = {};
        for (var i = 1; i <= $scope.columnTables1[0].length; i++) {
            $scope.element = $scope.columnTables1[0][i - 1].name;
            columns[$scope.element] = {};
            columns[$scope.element].label = $scope.columnTables1[0][i - 1].name;
        }

        if (operatorI > 0 && $('#flowChartDiv').flowchart('getOperatorData', $scope.tableNameSelected1[0]).properties != null)
            $('#flowChartDiv').flowchart('deleteOperator', $scope.tableNameSelected1[0]);

        var operatorId = $scope.tableNameSelected1[0];
        var columnsOperator = {
            name: $scope.tableNameSelected1,
            top: 60 * operatorI,
            left: 100,
            properties: {
                title: $scope.tableNameSelected1,
                outputs: columns
            }
        };
        operatorI++;

        $('#flowChartDiv').flowchart('createOperator', operatorId, columnsOperator);
    };

    $scope.saveColumnFromTables1 = function (column, table) {
        var alreadyAdded = false;
        angular.forEach($scope.TableAndColumns, function (value, index) {
            if (angular.equals($scope.TableAndColumns[index].name, column.name) && angular.equals($scope.TableAndColumns[index].table, table))
                alreadyAdded = true;
        });
        if (!alreadyAdded) {
            $scope.TableAndColumns.push({
                table: table,
                name: column.name,
                primaryKey: column.primaryKey,
                type: column.type,
                notNull: column.nullable,
                unique: column.unique,
                indexed: column.indexed,
                dataSource: {
                    id: $scope.connectionNameSelected1.id,
                    name: $scope.connectionNameSelected1.name,
                    url: $scope.connectionNameSelected1.url,
                    defaultPort: $scope.connectionNameSelected1.defaultPort,
                    username: $scope.connectionNameSelected1.username,
                    password: $scope.connectionNameSelected1.password,
                    dataSourceType: $scope.connectionNameSelected1.dataSourceType
                }
            });
            $scope.TableAndColumnsLength = $scope.TableAndColumns.length;

            $scope.columnFromTables1Clicked = 1;
            $scope.column1 = column;
            $scope.table1 = table;
        }
        else {
            $scope.TableAndColumns_temp = [];
            angular.forEach($scope.TableAndColumns, function (value, index) {
                if (!(angular.equals($scope.TableAndColumns[index].name, column.name) && angular.equals($scope.TableAndColumns[index].table, table)))
                    $scope.TableAndColumns_temp.push($scope.TableAndColumns[index]);
            });
            $scope.TableAndColumns = $scope.TableAndColumns_temp;
        }
        $scope.columnsTableLength = $scope.TableAndColumns.length;
    };

    $scope.selectDataSource2 = function () {
        $scope.tables2 = 0;
        $scope.dataSource2_isChosen = 1;
        $scope.tables2 = [];

        if (allDataSources.get($scope.connectionNameSelected2.id))
            $scope.tables2 = allDataSources.get($scope.connectionNameSelected2.id);
        else {
            var res = $http.get('/api/v1/dataSource/getDataSourceTables?id=' + $scope.connectionNameSelected2.id);
            res.then(function successCallback(data) {
                for (var j = 0; j < data.data.length; j++) {
                    $scope.tables2.push(data.data[j]);
                }
                allDataSources.set($scope.connectionNameSelected2.id, $scope.tables2);
            });
        }
        if (!editExtractionMode) {
            $scope.tableNameSelected2 = 0;
            $scope.columnTables2 = 0;
            $scope.columnFromTables2Clicked = 0;
            $scope.buttonPlus2clicked = 0;
            $scope.column2 = undefined;
            $scope.table2 = undefined;
            $scope.tables2Columns = [];
        }

        vm.tables2 = $scope.tables2;
    };

    $scope.tablesChanged2 = function () {
        $scope.buttonPlus2clicked = 0;
        $scope.columnFromTables2Clicked = 0;
        $scope.newtableName = "";
        $scope.column2 = undefined;
        $scope.table2 = undefined;
        $scope.tables2Columns = [];

        // $scope.tables1Columns
        angular.forEach($scope.tables2, function (item) {
            if ($scope.tableNameSelected2[0] && angular.equals(item.name, $scope.tableNameSelected2[0].replace(/\s/g, '')))
                $scope.tables2Columns = item.columns;
        });
    };

    $scope.nbrTables2 = 0;
    $scope.buttonPlus2clicked = 0;
    $scope.columnTables2_2 = [];

    $scope.showColumnsFromTables2 = function () {
        var destOperator = "_Dest";
        var operators = $('#flowChartDiv').flowchart('getData').operators;
        angular.forEach(operators, function (item) {
            if (item.name.indexOf(destOperator) !== -1) {
                $('#flowChartDiv').flowchart('deleteOperator', item.name.split("_Dest")[0]);
            }
        });

        // if ($('#flowChartDiv').flowchart('getOperatorData', $scope.tableNameSelected2[0].replace(/\s/g, '')).properties != null)


        $scope.buttonPlus2clicked = 1;
        $scope.nbrTables2 = $scope.tableNameSelected2.length;
        $scope.columnTables2 = [];
        $scope.columns = [];

        angular.forEach($scope.tables2, function (item) {
            if (angular.equals(item.name, $scope.tableNameSelected2[0].replace(/\s/g, '')))
                $scope.columnTables2.push(item.columns);
        });

        var k = 0;
        angular.forEach($scope.columnTables2[0], function () {
            var column = [];
            column = {column: $scope.columnTables2[0][k], isExisting: 0};
            k++;
            $scope.columns.push(column);
        });

        $scope.columnTables2 = {columns: $scope.columns};
        if (firstAdd == 1) {
            angular.forEach($scope.columnsAlreadyAdded, function (item) {
                angular.forEach($scope.columnTables2.columns, function (item2) {
                    if (item.name == item2.name && item.dataSource == $scope.connectionNameSelected2.name && item.table == $scope.tableNameSelected2)
                        item2.isExisting = 1;
                });
            });
        }

        $scope.columnTables2_2 = $scope.columnTables2.columns;

        var columns = {};
        for (var i = 1; i <= $scope.columnTables2_2.length; i++) {
            $scope.element = $scope.columnTables2_2[i - 1].column.name;
            columns[$scope.element] = {};
            columns[$scope.element].label = $scope.columnTables2_2[i - 1].column.name;
        }
        var operatorId = $scope.tableNameSelected2[0].replace(/\s/g, '');
        var columnsOperator = {
            name: $scope.tableNameSelected2[0].replace(/\s/g, '') + "_Dest",
            top: 50,
            left: 700,
            properties: {
                title: $scope.tableNameSelected2[0].replace(/\s/g, ''),
                inputs: columns
            }
        };

        $('#flowChartDiv').flowchart('createOperator', operatorId, columnsOperator);
        $('#flowChartDiv').flowchart({
            onLinkCreate: function (linkId, linkData) {
                var srcItem;
                angular.forEach($scope.tables1, function (item) {
                    if (angular.equals(item.name, linkData.fromOperator))
                        angular.forEach(item.columns, function (val) {
                            if (angular.equals(val.name, linkData.fromConnector))
                                srcItem = val;
                        });
                });
                $scope.saveColumnFromTables1(srcItem, linkData.fromOperator);
                $scope.saveColumnFromTables2(linkData.toConnector, linkData.toOperator);

                $scope.saveRelation(linkData.fromOperator, srcItem, linkData.toOperator, linkData.toConnector);
                return true;
            },
            onOperatorDelete: function (tableId) {
                $scope.deleteTableRelations(tableId);
                return true;
            },
            onLinkSelect: function (linkId) {
                var data = $('#flowChartDiv').flowchart('getData');
                $scope.linkData = data.links[linkId];
                return true;
            }
            ,
            onLinkDelete: function (linkId) {
                $scope.deleteRelation();
                return true;
            }
        });
    };

    $scope.createNewTable = function () {
        if ($scope.checked == 0) {
            $scope.column2 = null;
            $scope.table2 = null;
            $scope.columnFromTables2Clicked = 0;
            $scope.checked = 1;
            $scope.TableAndColumns = [];
            $scope.columnsTable = [];
            $scope.columnsTableLength = 0;
            $scope.showFlowChartDiv = false;
            $scope.showTablesDiv = true;
        }
        else {
            $scope.checked = 0;
            $scope.TableAndColumns = [];
            $scope.columnsTable = [];
            $scope.columnsTableLength = 0;
            $scope.showFlowChartDiv = true;
            $scope.showTablesDiv = false;
        }
    };

    $scope.columnFromTables2Clicked = 0;
    $scope.saveColumnFromTables2 = function (column, table) {
        $scope.columnFromTables2Clicked = 1;
        $scope.column2 = column;
        $scope.table2 = table;
    };

    $scope.relations = [];
    var firstAdd = 0;
    $scope.columnsAlreadyAdded = [];

    $scope.disabled = false;
    $scope.saveRelation = function (table1, column1, table2, column2) {
        $scope.existing = 0;

        var relation = [];
        var sourceFields = [];
        var destinationField = [];
        var sourceField = {
            name: column1.name,
            primaryKey: column1.primaryKey,
            type: column1.type,
            notNull: column1.nullable,
            unique: column1.unique,
            indexed: column1.indexed,
            table: table1,
            dataSource: {
                name: $scope.connectionNameSelected1.name,
                id: $scope.connectionNameSelected1.id,
                defaultPort: $scope.connectionNameSelected1.defaultPort,
                url: $scope.connectionNameSelected1.url,
                username: $scope.connectionNameSelected1.username,
                password: $scope.connectionNameSelected1.password,
                dataSourceType: $scope.connectionNameSelected1.dataSourceType
            }
        };

        angular.forEach($scope.relations, function (item) {
            if (column2 == item.outField.name) {
                item.inFields.push(sourceField);
                $scope.existing = 1;
            }
        });
        if ($scope.existing == 0) {
            sourceFields.push(sourceField);

            destinationField = {
                name: column2,
                table: table2,
                dataSource: {
                    name: $scope.connectionNameSelected2.name,
                    id: $scope.connectionNameSelected2.id,
                    url: $scope.connectionNameSelected2.url,
                    defaultPort: $scope.connectionNameSelected2.defaultPort,
                    username: $scope.connectionNameSelected2.username,
                    password: $scope.connectionNameSelected2.password,
                    dataSourceType: $scope.connectionNameSelected2.dataSourceType
                }
            };

            var relation = {
                inFields: JSON.parse(JSON.stringify(sourceFields)),
                outField: destinationField,
                type: 'CONCAT'
            };
            $scope.relations.push(relation);

            $scope.columnAlreadyAdded = {
                name: column2,
                table: table2,
                dataSource: $scope.connectionNameSelected2.name
            };
            $scope.columnsAlreadyAdded.push($scope.columnAlreadyAdded);
            angular.forEach($scope.columnsAlreadyAdded, function (item) {
                if (column2 == item.name) {
                    angular.forEach($scope.columnTables2.columns, function (item2) {
                        if (column2 == item2.name)
                            item2.isExisting = 1;
                    });
                }
            });
        }

        $scope.disabled = true;
        firstAdd = 1;

        $scope.disableSources = true;
        $scope.disableDestination = true;

        console.log($scope.relations);
    };

    $scope.deleteTableRelations = function (tableName) {
        angular.forEach($scope.relations, function (item, index) {
            if (angular.equals(item.outField.table, tableName))
                $scope.relations.splice(index, 1);
            else
                angular.forEach(item.inFields, function (val, i) {
                    if (angular.equals(val.table, tableName)) {
                        if (item.inFields.length == 1)
                            $scope.relations.splice(index, 1);
                        else
                            item.inFields.splice(i, 1);
                    }
                });
        });
        console.log($scope.relations);
    };

    $scope.deleteRelation = function () {
        angular.forEach($scope.relations, function (item, index) {
            angular.forEach(item.inFields, function (val, i) {
                if (angular.equals(val.table, $scope.linkData.fromOperator) && angular.equals(val.name, $scope.linkData.fromConnector)) {
                    if (item.inFields.length == 1)
                        $scope.relations.splice(index, 1);
                    else
                        item.inFields.splice(i, 1);
                }
            });
        });
        console.log($scope.relations);
    };

    $scope.saveMapping = function () {
        if (!$scope.mappingName)
            swal(
                'Warning',
                'Please specify a name to your extraction',
                'warning'
            );
        else if ($scope.relations.length > 0) {

            var tableExtraction = {
                importOption: $scope.importOption,
                tableName: $scope.tableNameSelected2[0].replace(/\s/g, ''),
                create_table: false,
                mappingList: $scope.relations,
                joins: $scope.joins,
                filters: $scope.filters,
                flowChartData: JSON.stringify(($('#flowChartDiv').flowchart('getData')))
            };

            extractionName = $scope.mappingName;

            if (editExtractionMode) {
                tableExtraction.id = extractionId;

                var res = $http.post('/api/v1/extraction/editExtraction?id=' + extractionId, angular.toJson(tableExtraction));
                res.then(function successCallback(data) {
                    console.log(data);
                });

                swal("Successfully edited !", "").then(function () {
                    location.reload();
                    extractionName = "";
                });
            }

            else {
                swal({
                    title: 'Successfully saved',
                    text: "Do you want to save and continue or terminate ?",
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Continue',
                    cancelButtonText: 'Save and terminate',
                    confirmButtonClass: 'btn btn-success',
                    cancelButtonClass: 'btn btn-danger',
                    buttonsStyling: false
                }).then(function () {
                        swal("Success !", "Please continue").then(function () {
                            // tableExtractions ARRAY
                            tableExtractions.push(tableExtraction);
                            extractionDataSource = $scope.connectionNameSelected2;
                            $state.reload();
                        });
                    },
                    function (dismiss) {
                        if (dismiss === 'cancel') {
                            // tableExtractions ARRAY
                            tableExtractions.push(tableExtraction);

                            var extraction = {
                                name: $scope.mappingName,
                                tableExtractions: tableExtractions,
                                dataSource: $scope.connectionNameSelected2
                            };

                            console.log(angular.toJson(extraction));
                            extractionDataSource = undefined;

                            var res = $http.post('/api/v1/extraction/saveExtraction', angular.toJson(extraction));
                            res.then(function successCallback(data) {
                                console.log(data);
                            });
                            swal("Saved !", "").then(function () {
                                location.reload();
                                extractionName = "";
                            });
                        }
                    });

                $scope.disableSources = false;
                $scope.disableDestination = false;
            }
        }
        else
            swal(
                'Warning',
                'Create at least one mapping',
                'warning'
            );
    };

    $scope.saveMappingWithNewTable = function () {
        if (!$scope.newtableName || $scope.newtableName == '')
            swal(
                'Warning',
                'Specify the new table name',
                'warning'
            );
        else if (!$scope.connectionNameSelected2)
            swal(
                'Warning',
                'Choose a dataSource destination',
                'warning'
            );
        else if (!$scope.mappingName)
            swal(
                'Warning',
                'Specify the extraction name',
                'warning'
            );
        else if ($scope.TableAndColumns.length > 0) {
            var newRelations = [];

            angular.forEach($scope.TableAndColumns, function (item) {
                var sourceFields = [];
                var sourceField = {
                    name: item.name,
                    primaryKey: item.primaryKey,
                    type: item.type,
                    notNull: item.notNull,
                    unique: item.unique,
                    indexed: item.indexed,
                    table: item.table,
                    dataSource: item.dataSource
                };

                sourceFields.push(sourceField);

                var destinationField = {
                    name: item.name,
                    primaryKey: item.primaryKey,
                    type: item.type,
                    notNull: item.nullable,
                    unique: item.unique,
                    indexed: item.indexed,
                    table: $scope.newtableName,
                    dataSource: {
                        id: $scope.connectionNameSelected2.id,
                        name: $scope.connectionNameSelected2.name,
                        url: $scope.connectionNameSelected2.url,
                        defaultPort: $scope.connectionNameSelected2.defaultPort,
                        username: $scope.connectionNameSelected2.username,
                        password: $scope.connectionNameSelected2.password,
                        dataSourceType: $scope.connectionNameSelected2.dataSourceType
                    }
                };
                var relation = {
                    inFields: JSON.parse(JSON.stringify(sourceFields)),
                    outField: destinationField,
                    type: 'CONCAT'
                };
                newRelations.push(relation);
            });

            extractionName = $scope.mappingName;

            var tableExtraction = {
                importOption: $scope.importOption,
                tableName: $scope.newtableName,
                create_table: true,
                mappingList: newRelations,
                joins: $scope.joins,
                filters: $scope.filters
            };

            if (editExtractionMode) {
                tableExtraction.id = extractionId;

                var res = $http.post('/api/v1/extraction/editExtraction?id=' + extractionId, angular.toJson(tableExtraction));
                res.then(function successCallback(data) {
                    console.log(data);
                });

                swal("Successfully edited !", "").then(function () {
                    location.reload();
                    extractionName = "";
                });
            }

            else {
                swal({
                    title: 'Successfully saved',
                    text: "Do you want to save and continue or terminate ?",
                    type: 'success',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#06dd94',
                    confirmButtonText: 'Continue',
                    cancelButtonText: 'Save and terminate',
                    confirmButtonClass: 'btn btn-success',
                    cancelButtonClass: 'btn btn-danger',
                    buttonsStyling: false
                }).then(function () {
                        swal(
                            'Success',
                            'Please continue',
                            'success'
                        );
                        // tableExtractions ARRAY
                        tableExtractions.push(tableExtraction);
                        console.log(tableExtractions);
                        $state.reload();
                    },
                    function (dismiss) {
                        if (dismiss === 'cancel') {
                            // tableExtractions ARRAY
                            tableExtractions.push(tableExtraction);

                            var extraction = {
                                name: $scope.mappingName,
                                tableExtractions: tableExtractions,
                                dataSource: $scope.connectionNameSelected2
                            };

                            var res = $http.post('/api/v1/extraction/saveExtraction', angular.toJson(extraction));
                            res.then(function successCallback(data) {
                                console.log(data);
                            });

                            swal("Saved !", "").then(function () {
                                location.reload();
                                extractionName = "";
                            });
                        }
                    });
            }

            $scope.disableSources = false;
            $scope.disableDestination = false;
        }
        else
            swal(
                'Warning',
                'Create at least one mapping',
                'warning'
            );
    };

    $scope.getLeftTableColumns = function () {
        $scope.leftTableColumns = [];

        angular.forEach($scope.tables1, function (item) {
            if (angular.equals($scope.leftTable, item.name))
                $scope.leftTableColumns = item.columns;
        });

    };

    $scope.getRightFieldDataSourceTables = function () {
        $scope.rightFieldDataSourceTables = [];
        if (allDataSources.get($scope.rightFieldDataSource.id))
            $scope.rightFieldDataSourceTables = allDataSources.get($scope.rightFieldDataSource.id);
        else {
            var res = $http.get('/api/v1/dataSource/getDataSourceTables?id=' + $scope.rightFieldDataSource.id);
            res.then(function successCallback(data) {
                for (var j = 0; j < data.data.length; j++) {
                    $scope.rightFieldDataSourceTables.push(data.data[j]);
                }
                allDataSources.set($scope.rightFieldDataSource.id, $scope.rightFieldDataSourceTables);
            });
        }
    };

    $scope.getRightTableColumns = function () {
        $scope.rightTableColumns = [];

        angular.forEach($scope.tables1, function (item) {
            if (angular.equals($scope.rightTable, item.name))
                $scope.rightTableColumns = item.columns;
        });
    };

    $scope.addJoin = function () {
        if (fired) {
            if (!$scope.joinType)
                swal(
                    'Warning',
                    'Please select a join type',
                    'warning'
                );
            else if (!$scope.leftTable)
                swal(
                    'Warning',
                    'Please select a left table',
                    'warning'
                );
            else if (!$scope.leftColumn)
                swal(
                    'Warning',
                    'Please select a left column',
                    'warning'
                );
            else if (!$scope.rightTable)
                swal(
                    'Warning',
                    'Please select a right table',
                    'warning'
                );
            else if (!$scope.rightColumn)
                swal(
                    'Warning',
                    'Please select a right column',
                    'warning'
                );
            else if (
                angular.equals($scope.leftTable, $scope.rightTable))
                swal(
                    'Warning',
                    'You can not create a join with the same table !',
                    'warning'
                );
            else {
                var pushIt = true;

                angular.forEach($scope.joins, function (item, index) {
                    if (angular.equals(item.leftField.name, JSON.parse($scope.leftColumn).name) && angular.equals(item.leftField.table, $scope.leftTable) &&
                        angular.equals(item.leftField.dataSource, $scope.leftFieldDataSource) && angular.equals(item.rightField.name, JSON.parse($scope.rightColumn).name)
                        && angular.equals(item.rightField.table, $scope.leftTable) && angular.equals(item.rightField.dataSource, $scope.rightFieldDataSource))
                        pushIt = false;
                });

                if (pushIt) {
                    var leftField = JSON.parse($scope.leftColumn);
                    var rightField = JSON.parse($scope.rightColumn);

                    leftField.dataSource = $scope.leftFieldDataSource;
                    leftField.table = $scope.leftTable;

                    rightField.dataSource = $scope.rightFieldDataSource;
                    rightField.table = $scope.leftTable;

                    var join = {
                        type: $scope.joinType,
                        leftField: leftField,
                        rightField: rightField
                    };
                    $scope.joins.push(join);
                    $('#dataSourceJoinModal').modal('hide');

                    // INITIALIZE SCOPES
                    $scope.rightTable = "";
                    $scope.rightColumn = "";
                    $scope.leftTable = "";
                    $scope.leftColumn = "";
                    $scope.leftTableColumns = [];
                    $scope.rightTableColumns = [];
                }
            }
            fired = false;
        }
    };

    $scope.deleteFromJoins = function (join) {
        angular.forEach($scope.joins, function (item, index) {
            if (angular.equals(item, join))
                $scope.joins.splice(index, 1);
        });
    };

    $scope.addFilter = function () {
        if (($scope.relations.length > 0 || $scope.TableAndColumns.length > 0) && !$scope.flag) {
            dialog = bootbox.dialog({
                message: ' <div id="builder-basic"></div><div align="center" id="buttonsDiv"> <button type="button" class="btn btn-primary" ' +
                'title="Apply filters" ng-click="saveColumnFilter()">Save</button>' +
                '    <button type="button" class="btn btn-primary" title="Cancel" onclick="hideFiltersModal()"> Cancel </button></div>',
                closeButton: false
            });
            var inputs = [];

            if ($scope.checked == 1) {
                angular.forEach($scope.TableAndColumns, function (item) {
                    var input = {
                        id: item.table + '.' + item.name,
                        label: item.table + '.' + item.name,
                        type: 'string',
                        operators: ['greater', 'greater_or_equal', 'less', 'less_or_equal',
                            'equal', 'not_equal', 'is_null', 'is_not_null']
                    };
                    inputs.push(input);
                });
            }
            else {
                angular.forEach($scope.relations, function (item) {
                    angular.forEach(item.inFields, function (val) {
                        var input = {
                            id: val.table + '.' + val.name,
                            label: val.table + '.' + val.name,
                            type: 'string',
                            operators: ['greater', 'greater_or_equal', 'less', 'less_or_equal',
                                'equal', 'not_equal', 'is_null', 'is_not_null']
                        };
                        inputs.push(input);
                    });
                });
            }

            var element = angular.element(document.querySelector('#buttonsDiv'));

            $('#builder-basic').queryBuilder({
                // plugins: ['bt-tooltip-errors'],
                filters: inputs
            });

            $scope.flag = true;

            $compile(element.contents())($scope);
        }
        else if (!$scope.flag)
            swal(
                'Warning',
                'Please create at least one mapping before adding filters',
                'warning'
            );
    };

    $scope.saveColumnFilter = function () {
        var result = $("#builder-basic").queryBuilder('getSQL', $(this).data('stmt'));
        if (!$.isEmptyObject(result)) {
            var e = document.getElementsByName("builder-basic_rule_0_filter");
            var selectedField = e[0].options[e[0].selectedIndex].value;

            angular.forEach($scope.relations, function (item) {
                angular.forEach(item.inFields, function (val, i) {
                    if (angular.equals(selectedField.split('.')[0], val.table) && angular.equals(selectedField.split('.')[1], val.name))
                        srcField = val;
                });
            });

            var operator = $('#builder-basic').queryBuilder('getRules').rules[0].operator.toUpperCase();
            switch (operator) {
                case "GREATER":
                    operator = "GREATER_THAN";
                    break;
                case "GREATER_OR_EQUAL" :
                    operator = "GREATER_THAN_OR_EQUAL";
                    break;
                case "LESS" :
                    operator = "LESS_THAN";
                    break;
                case "LESS_OR_EQUAL" :
                    operator = "LESS_THAN_OR_EQUAL";
                    break;
                default:
                    operator = operator;
                    break;
            }

            var obj = {
                field: srcField,
                operator: operator,
                value: $('#builder-basic').queryBuilder('getRules').rules[0].value
            };

            $scope.filters.push(obj);

        }
        dialog.modal('hide');
    };

    $scope.deleteFromFilters = function (filter) {
        angular.forEach($scope.filters, function (item, index) {
            if (angular.equals(item, filter))
                $scope.filters.splice(index, 1);
        });
    };

    if (!editExtractionMode && extractionDataSource) {
        $scope.connectionNameSelected2 = extractionDataSource;
        $scope.selectDataSource2();
        $scope.disableDestination = true;
        $scope.mappingName = extractionName;
    }
});