/**
 * Created by Anass on 07/07/2017.
 */

app.run(function ($rootScope, $http) {
    var res = $http.get('/api/v1/extraction/getAllTaskTriggerPeriods');
    res.then(function successCallback(data) {
        $rootScope.periods = data.data.taskTriggerPeriods;
    });
});

app.controller("extractions", function ($scope, $http) {
    editDataSourceMode = false;
    editExtractionMode = false;
    tableExtractions = [];
    $scope.selectedWeekOfMonth = [];
    $scope.days = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
    $scope.weeks = [{
        id: "1",
        name: "First week"
    }, {
        id: "2",
        name: "Second week"
    }, {
        id: "3",
        name: "Third week"
    }, {
        id: "4",
        name: "Fourth week"
    }, {
        id: "5",
        name: "Fifth week"
    }];

    $("#weekDays").select2();
    $scope.showWeekDays = false;
    $("#weeksOfMonth").select2();

    $scope.onPeriodChange = function () {
        switch ($scope.period) {
            case "IMMEDIATELY" :
                $scope.timePicker = false;
                $scope.dateAndTimePicker = false;
                $scope.showWeekDays = false;
                break;

            case "ONLY_ONCE" :
                $scope.timePicker = false;
                $scope.dateAndTimePicker = true;
                $scope.showWeekDays = false;
                break;

            case "WEEKLY" :
                $scope.timePicker = true;
                $scope.dateAndTimePicker = false;
                $scope.showWeekDays = true;
                break;

            case "MONTHLY" :
                $scope.dateAndTimePicker = true;
                $scope.timePicker = false;
                $scope.showWeekDays = false;
                break;

            case "PERIODICALLY" :
                $scope.timePicker = true;
                $scope.dateAndTimePicker = false;
                $scope.showWeekDays = false;
                break;
        }
    };

    $scope.addTableExtractionScheduler = function () {
        var valueToPost = "";
        switch ($scope.period) {
            case "IMMEDIATELY" :
                valueToPost = dateFormat(new Date(), 'd/m/Y H:i:s');
                $scope.postScheduler(valueToPost);
                break;

            case "MONTHLY" :
            case "ONLY_ONCE" :
                $scope.timePicker = false;
                $scope.dateAndTimePicker = false;
                valueToPost = $("#dateTimePicker").find("input").val();
                $scope.postScheduler(valueToPost);
                break;

            case "WEEKLY" :
                if (!$scope.selectedDays)
                    alert('Please select at least one day of week ! ');
                else {
                    $scope.timePicker = false;
                    $scope.dateAndTimePicker = false;
                    $scope.showWeekDays = false;
                    valueToPost = $("#timePickerInput").find("input").val();
                    valueToPost += " " + $scope.getSelectedWeekDays();
                    $scope.selectedDays = [];
                    $scope.selectedWeekOfMonth = [];
                    $scope.postScheduler(valueToPost);
                }
                break;

            case "PERIODICALLY" :
                $scope.timePicker = false;
                $scope.dateAndTimePicker = false;
                valueToPost = $("#timePickerInput").find("input").val();
                $scope.postScheduler(valueToPost);
                break;
        }
    };

    $scope.postScheduler = function (valueToPost) {
        console.log(valueToPost);
        var taskScheduler = {
            taskTriggerPeriod: $scope.period,
            date: valueToPost
        };

        var res = $http.post('/api/v1/extraction/setTaskSchedulerCron?id=' + extractionId, angular.toJson(taskScheduler));
        $scope.period = "";
        $('#schedulingModal').modal('hide');
        res.then(function successCallback(data) {
            if (data.data.success)
                swal(data.data.success, "").then(function () {

                });
            else
                swal({
                        title: 'Connection failed',
                        text: 'You have errors : ' + data.data.error,
                        showCancelButton: false,
                        confirmButtonColor: '#3085d6',
                        confirmButtonText: 'Retry !'
                    }
                )
        });
    };

    $scope.getSelectedWeekDays = function () {
        var selectedWeekDays = "";
        angular.forEach($scope.selectedDays, function (item, index) {
            selectedWeekDays += item;
            if ($scope.selectedDays.length > 1 && index < $scope.selectedDays.length - 1)
                selectedWeekDays += ",";
        });
        if ($scope.selectedWeekOfMonth.length > 0)
            selectedWeekDays += "#";
        angular.forEach($scope.selectedWeekOfMonth, function (item, index) {
            selectedWeekDays += item;
            if ($scope.selectedWeekOfMonth.length > 1 && index < $scope.selectedWeekOfMonth.length - 1)
                selectedWeekDays += ",";
        });
        return selectedWeekDays;
    }
});

function deleteExtraction(id) {
    $.post('/api/v1/extraction/deleteExtraction?id=' + id);
    location.reload();
}

function editExtraction(id, name) {
    editExtractionMode = true;
    extractionId = id;
    extractionName = name;
    swal('Please wait');
    swal.showLoading();
    document.getElementById("tableExtraction").click();
}

function runExtraction(id) {

}

function manageExtraction(id) {
    extractionId = id;
    $('#schedulingModal').modal('show');
}