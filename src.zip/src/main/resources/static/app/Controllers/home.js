app.controller("homeController", function ($scope) {
    var vm = this;
    vm.tables = [];

    $scope.showSelected = function (selected) {

        console.log("salut");
        console.log(selected)
    };


    var p = $("#myCanvas");
    var offset = p.offset();
    $scope.canvasTop = offset.top;
    $scope.canvasLeft = offset.left;


    var c = document.getElementById("myCanvas");
    var context = c.getContext("2d");

    $scope.drawn = 0;

    $scope.beginDrawing = function () {
        if ($scope.drawn = 1) {
            context.clearRect(0, 0, c.width, c.height);
            context.restore();
            var p = $("#element1");
            var offset = p.offset();
            $scope.top1 = offset.top;
            $scope.left1 = offset.left

        }
        else if ($scope.drawn = 0) {
            var p = $("#element1");
            var offset = p.offset();
            $scope.top1 = offset.top;
            $scope.left1 = offset.left

        }

    };

    $scope.beginDrawing2 = function () {
        if ($scope.drawn = 1) {
            context.clearRect(0, 0, c.width, c.height);
            context.restore();
            var p = $("#element3");
            var offset = p.offset();
            $scope.top1 = offset.top;
            $scope.left1 = offset.left

        }
        else if ($scope.drawn = 0) {
            var p = $("#element1");
            var offset = p.offset();
            $scope.top1 = offset.top;
            $scope.left1 = offset.left

        }

    };
    function canvas_arrow(context, fromx, fromy, tox, toy) {
        context.beginPath();
        var headlen = 10;   // length of head in pixels
        var angle = Math.atan2(toy - fromy, tox - fromx);
        context.moveTo(fromx, fromy);
        context.lineTo(tox, toy);
        context.lineTo(tox - headlen * Math.cos(angle - Math.PI / 6), toy - headlen * Math.sin(angle - Math.PI / 6));
        context.moveTo(tox, toy);
        context.lineTo(tox - headlen * Math.cos(angle + Math.PI / 6), toy - headlen * Math.sin(angle + Math.PI / 6));
        context.lineWidth = 2;
        context.strokeStyle = '#ff0000';
        context.stroke();
        $scope.drawn = 1
    }

    $scope.finishDrawing = function () {


        var p = $("#element2");
        var offset = p.offset();
        $scope.top2 = offset.top;
        $scope.left2 = offset.left;
        console.log($scope.left2 + " " + $scope.top2);


        var left1 = $scope.left1;
        var left2 = $scope.left2;
        var top1 = $scope.top1;
        var top2 = $scope.top2;
        var canvasLeft = $scope.canvasLeft;
        var canvasTop = $scope.canvasTop;
        //context.moveTo(left1+15,top1+15);
        //context.lineTo(left2+15,top1+15);
        canvas_arrow(context, left1 - canvasLeft + 30, 0, left2 - canvasLeft + 30, 100)


    }

});