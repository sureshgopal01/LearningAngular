app.run(function ($rootScope, $http) {
    var res = $http.get('/getDataSourceTypes');
    res.then(function successCallback(data) {
        $rootScope.databaseTypes = data.data;
    });
});


app.controller("testConnectionController", function ($scope, $http) {
    editExtractionMode = false;
    tableExtractions = [];

        if (editDataSourceMode) {
            var res = $http.get('/api/v1/dataSource/getDataSourceById?id=' + dataSourceId);
            res.then(function successCallback(data) {
                $scope.dataSource = data.data;
                $scope.name = $scope.dataSource.name;
                $scope.url = $scope.dataSource.url;
                $scope.port = parseInt($scope.dataSource.defaultPort);
                $scope.user = $scope.dataSource.username;
                $scope.pwd = $scope.dataSource.password;
                $scope.type = $scope.dataSource.dataSourceType;
                swal.close();
            });
        }
        else {
            $scope.name = "";
            $scope.url = "";
            $scope.port = 0;
            $scope.user = "";
            $scope.pwd = "";
            $scope.type = "";
        }

        $scope.test = function () {
            if (!$scope.name)
                swal(
                    'Warning',
                    'Specify the data source name',
                    'warning'
                );

            else if (!$scope.url)
                swal(
                    'Warning',
                    'Specify the data source url',
                    'warning'
                );

            else if (!$scope.port)
                swal(
                    'Warning',
                    'Specify the data source default port',
                    'warning'
                );

            else if (!$scope.user)
                swal(
                    'Warning',
                    'Specify the data source username',
                    'warning'
                );

            else if (!$scope.pwd)
                swal(
                    'Warning',
                    'Specify the data source password',
                    'warning'
                );

            else if (!$scope.type)
                swal(
                    'Warning',
                    'Specify the data source type',
                    'warning'
                );

            else {

                var ds = {
                    name: $scope.name,
                    url: $scope.url,
                    defaultPort: parseInt($scope.port),
                    username: $scope.user,
                    password: $scope.pwd,
                    dataSourceType: $scope.type
                };

                var data = $http.post('/api/v1/dataSource/testConnection', ds);
                data.then(function (res) {
                    if (res.data.success) {
                        swal({
                            title: 'Successfully Connected',
                            text: "Do you want to save this data source ?",
                            type: 'success',
                            showCancelButton: true,
                            confirmButtonColor: '#3085d6',
                            cancelButtonColor: '#d33',
                            confirmButtonText: 'Yes, save it',
                            cancelButtonText: 'No, cancel',
                            confirmButtonClass: 'btn btn-success',
                            cancelButtonClass: 'btn btn-danger',
                            buttonsStyling: false
                        }).then(function () {
                                $scope.save();
                            },
                            function (dismiss) {
                                if (dismiss === 'cancel') {
                                    swal(
                                        'Cancelled',
                                        'Your connection was not saved',
                                        'error'
                                    )
                                }
                            });
                    }
                    else {
                        swal(
                            'Connection failed !',
                            'You have errors :  ' + res.data.failure,
                            'error'
                        )
                    }
                });
            }


        };

        $scope.save = function () {
            var ds = {
                name: $scope.name,
                url: $scope.url,
                defaultPort: parseInt($scope.port),
                username: $scope.user,
                password: $scope.pwd,
                dataSourceType: $scope.type
            };

            if (editDataSourceMode) {
                $http.post('/api/v1/dataSource/editDataSource?id=' + $scope.dataSource.id, ds);
                dataSourceId = 0;
                editDataSourceMode = false;
            }
            else
                $http.post('/api/v1/dataSource/saveDataSource', ds);

            swal("Successfully saved !", "").then(function () {
                location.reload();
            });
        }

    }
);