package com.itssglobal.sigma.dataintegrator.Mapping;

import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

/**
 * Created by Anass on 20/06/2017.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class MappingControllerTest {
}
