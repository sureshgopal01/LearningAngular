import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatasourceService } from '../../services/datasource.service';
import { DataSource } from '../../models/datasource';
import { Http } from '@angular/http';


@Component({
  templateUrl: './datasources.component.html'
})
export class DatasourcesComponent implements OnInit {
datasources: Array<any> = [];
baseUrl = 'http://localhost:8181';
// datasources: DataSource;
errorMessage: any;
currentId = 0;
serarchText = '';

constructor(private dsService: DatasourceService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute) { }

/*constructor(http: Http) {
  http.get(this.baseUrl + '/api/v1/dataSource/getAllSources').subscribe(result => {
      // this.datasources = result.json() as DataSource[];
      this.datasources = result.json().datasources;
  }, error => console.error(error));
}
}*/

getDataSources() {
      this.dsService.getDataSources().subscribe(
          data => {
            // this.datasources.push( data);
            // this.datasources: any = data;
            this.datasources = data;
            // this.datasources = Array.of(this.datasources);
            console.log(data);
           },
          error => this.errorMessage = error
      );
  }
  // call this function in ngOnInit to call on page loading
  ngOnInit() {
    /*if (this._activatedRoute.snapshot.params['id']) {
      this.currentId = parseInt(this._activatedRoute.snapshot.params['id']);
    }*/
    this.getDataSources();
  }
  edit(id) {
    this._router.navigate(['/base/cards/' + id]);
  }
  delete(id) {
    const ans = confirm('Do you want to delete DataSource with Id: ' + id);
    if (ans) {
      this.dsService.deleteDatasource(id)
          .subscribe(  data => {
            var index = this.datasources.findIndex(x => x.id === id);
            this.datasources.splice(index, 1);
          }, error => this.errorMessage = error );
    }
  }

}
