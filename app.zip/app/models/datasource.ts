export interface DataSource {
	id: number;
	name: string;
	url: string;
	defaultPort: string;
	username: string;
	password: string;
	dataSourceType: string;
}
