import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { catchError } from 'rxjs/operators';
import { DataSource } from '../models/datasource';

@Injectable({
  providedIn: 'root'
})
export class ExtractionService {

  baseUrl = 'http://localhost:8181';
  dataTables: any[];

  constructor(private _http: Http) { }

  getDataTables(conName: String) {
    const tables = this._http.get(this.baseUrl + '/api/v1/dataSource/getDataSourceTables?id=' + conName)
      .pipe(map((response: Response) => response.json()), catchError(this._errorHandler));
      console.log('After calling getDataSources tables' + tables);
      console.log('After calling getDataSources response.JSON ' + Response.toString);
      return tables;
  }

  getTableCoumns(dsName: Number, tableName: String) {
    const columns = this._http.get(this.baseUrl + '/api/v1/dataSource/getDataSourceTableColumns?id=' + dsName + '&tableName=' +  tableName)
      .pipe(map((response: Response) => response.json()), catchError(this._errorHandler));
      console.log('After calling getDataSources interim' + columns);
      console.log('After calling getDataSources response.JSON ' + Response.toString);
      return columns;
  }

  _errorHandler(error: Response) {
    // debugger;
    console.log(error);
    return Observable.throw(error || 'Internal server error');
  }
}
