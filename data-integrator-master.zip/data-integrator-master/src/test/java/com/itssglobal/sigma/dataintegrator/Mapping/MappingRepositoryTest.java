package com.itssglobal.sigma.dataintegrator.Mapping;

import com.itssglobal.sigma.dataintegrator.domain.*;
import com.itssglobal.sigma.dataintegrator.repository.DataStoreRepository;
import com.itssglobal.sigma.dataintegrator.repository.ExtractionRepository;
import com.itssglobal.sigma.dataintegrator.util.JsonUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.Collections;

/**
 * Created by Anass on 20/06/2017.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class MappingRepositoryTest {

    @Autowired
    ExtractionRepository extractionRepository;

    @Autowired
    DataStoreRepository dataStoreRepository;

    @Test
    public void shouldSaveExtraction() {
        Extraction extraction = new Extraction();
        extraction.setName("NEW_EXTRACTION");
        TableExtraction tableExtraction = new TableExtraction();
        tableExtraction.setCreate_table(false);
        DataStore mySQLDataStore = MappingHelper.createNewMySQLDataSource("dataIntegrator_db");
        Field sourceField = MappingHelper.createNewField("SOURCE_FIELD", "SOURCE_TABLE");
        sourceField.setDataSource(mySQLDataStore);
        Field destinationField = MappingHelper.createNewField("DESTINATION_FIELD", "DESTINATION_TABLE");
        destinationField.setDataSource(mySQLDataStore);
        FieldJoin fieldJoin = MappingHelper.createNewFieldJoin(MappingHelper.createNewField("RIGHT_FIELD", "SOURCE_TABLE_1"),
                MappingHelper.createNewField("LEFT_FIELD", "SOURCE_TABLE_2"), JoinType.UNION_ALL);
        FieldMapping fieldMapping = MappingHelper.createNewFieldMapping(Collections.singletonList(sourceField), destinationField);
        tableExtraction.setMappingList(Collections.singletonList(fieldMapping));
        tableExtraction.setJoins(Collections.singletonList(fieldJoin));
        extraction.setTableExtractions(Collections.singletonList(tableExtraction));
        dataStoreRepository.save(mySQLDataStore);
        extractionRepository.save(extraction);
        System.out.println(JsonUtils.toJson(tableExtraction));
    }
}
