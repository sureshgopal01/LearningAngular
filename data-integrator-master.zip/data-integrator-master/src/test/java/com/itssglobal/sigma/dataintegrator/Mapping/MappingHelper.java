package com.itssglobal.sigma.dataintegrator.Mapping;

import com.itssglobal.sigma.dataintegrator.domain.*;
import com.itssglobal.sigma.dataintegrator.util.DataSourceUtils;

import java.util.List;

/**
 * Created by Anass on 20/06/2017.
 */
public class MappingHelper {

    public static FieldMapping createNewFieldMapping(List<Field> sourceFields, Field destinationField) {
        FieldMapping fieldMapping = new FieldMapping();
        fieldMapping.setInFields(sourceFields);
        fieldMapping.setOutField(destinationField);
        return fieldMapping;
    }

    public static Field createNewField(String name, String tableName) {
        Field field = new Field();
        field.setName(name);
        field.setTable(tableName);
        return field;
    }

    public static DataStore createNewMySQLDataSource(String name) {
        DataStore mySQLDataStore = new DataStore();
        mySQLDataStore.setDataSourceType(DataSourceUtils.DataSourceType.MYSQL);
        mySQLDataStore.setDefaultPort(3306);
        mySQLDataStore.setName(name);
        mySQLDataStore.setUrl("localhost");
//        mySQLDataStore.setUsername("root");
//        mySQLDataStore.setPassword("itss2016");
        mySQLDataStore.setUsername("itss");
        mySQLDataStore.setPassword("itss2018");
        return mySQLDataStore;
    }

    public static FieldJoin createNewFieldJoin(Field rightField, Field leftField, JoinType joinType) {
        FieldJoin fieldJoin = new FieldJoin();
        fieldJoin.setLeftField(leftField);
        fieldJoin.setRightField(rightField);
        fieldJoin.setType(joinType);
        return fieldJoin;
    }
}
