package com.itssglobal.sigma.dataintegrator.DataSource;

import com.itssglobal.sigma.dataintegrator.domain.DataStore;
import com.itssglobal.sigma.dataintegrator.pojo.TableMetadata;
import com.itssglobal.sigma.dataintegrator.repository.DataStoreRepository;
import com.itssglobal.sigma.dataintegrator.rest.DataSourceController;
import com.itssglobal.sigma.dataintegrator.service.DataSourceService;
import com.itssglobal.sigma.dataintegrator.util.DataSourceUtils;
import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by Anass on 14/06/2017.
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class DataStoreRepositoryTest {

	@Autowired
	DataSourceController dataSourceController;

	@Autowired
	private DataStoreRepository dataStoreRepository;

	@Autowired
	private DataSourceUtils dataSourceUtils;

	@Test
	public void shouldSaveDataSourceAndCreateDataSourceURL() {
		DataSourceService dataSourceService = new DataSourceService();
		DataStore mySQLDataStore = new DataStore();
		mySQLDataStore.setDataSourceType(DataSourceUtils.DataSourceType.MYSQL);
		mySQLDataStore.setDefaultPort(3306);
		mySQLDataStore.setName("dataIntegrator_db");
		mySQLDataStore.setUrl("localhost");
		// mySQLDataStore.setUsername("root");
		// mySQLDataStore.setPassword("itss2016");
		mySQLDataStore.setUsername("itss");
		mySQLDataStore.setPassword("itss2018");
		dataStoreRepository.save(mySQLDataStore);
		DataStore oracleDataStore = new DataStore();
		oracleDataStore.setDataSourceType(DataSourceUtils.DataSourceType.ORACLE);
		oracleDataStore.setDefaultPort(1521);
		oracleDataStore.setName("dataSourceName");
		oracleDataStore.setUrl("localhost");
		DataStore sqlServerDataStore = new DataStore();
		sqlServerDataStore.setDataSourceType(DataSourceUtils.DataSourceType.SQL_SERVER);
		sqlServerDataStore.setDefaultPort(1433);
		sqlServerDataStore.setName("DATABASE");
		sqlServerDataStore.setUrl("localhost");
		assertThat(DataSourceService.getDataSourceURL(mySQLDataStore))
				.isEqualTo("jdbc:mysql://localhost:3306/dataIntegrator_db");
		assertThat(DataSourceService.getDataSourceURL(oracleDataStore))
				.isEqualTo("jdbc:oracle:thin:@localhost:1521:dataSourceName");
		assertThat(DataSourceService.getDataSourceURL(sqlServerDataStore))
				.isEqualTo("jdbc:microsoft:sqlserver://localhost:1433;DatabaseName=DATABASE");
	}

	@Test
	public void testDatabaseConnectionSuccess() {
		DataStore mySQLDataStore = new DataStore();
		mySQLDataStore.setDataSourceType(DataSourceUtils.DataSourceType.MYSQL);
		mySQLDataStore.setDefaultPort(3306);
		mySQLDataStore.setName("dataIntegrator_db");
		mySQLDataStore.setUrl("localhost");
		// mySQLDataStore.setUsername("root");
		// mySQLDataStore.setPassword("itss2016");
		mySQLDataStore.setUsername("itss");
		mySQLDataStore.setPassword("itss2018");
		dataStoreRepository.save(mySQLDataStore);
		try {
			assertThat(dataSourceController.testDataSourceConnection(mySQLDataStore)).isNotNull();
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}

	@Test
	public void getDatabaseTables() {
		DataStore mySQLDataStore = new DataStore();
		mySQLDataStore.setDataSourceType(DataSourceUtils.DataSourceType.MYSQL);
		mySQLDataStore.setDefaultPort(3306);
		mySQLDataStore.setName("dataIntegrator_db");
		mySQLDataStore.setUrl("localhost");
		// mySQLDataStore.setUsername("root");
		// mySQLDataStore.setPassword("itss2016");
		mySQLDataStore.setUsername("itss");
		mySQLDataStore.setPassword("itss2018");
		dataStoreRepository.save(mySQLDataStore);
		assertThat(dataSourceController.getDataSourceTables(1L)).isNotEmpty();
		TableMetadata tableMetadata = new TableMetadata();
		tableMetadata.setName("actor");
		assertThat(dataSourceController.getDataSourceTables(1L).contains(tableMetadata));
	}

	@Test
	public void shouldReturnDataBaseTypes() {
		assertThat(dataSourceUtils.getDataSourceTypes()).isNotEmpty();
	}
}
