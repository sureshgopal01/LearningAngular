package com.itssglobal.sigma.dataintegrator.util;

import com.itssglobal.sigma.dataintegrator.domain.JoinType;
import lombok.Getter;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Anass on 13/06/2017.
 */
@RestController
public class DataSourceUtils {

    @ResponseBody
    @GetMapping("/getDataSourceTypes")
    public List<String> getDataSourceTypes() {
        List<String> types = new ArrayList<>();
        System.out.println("Inside the getDataSourceType");
        for (DataSourceType dataSourceType : DataSourceType.values()) {
            types.add(dataSourceType.name());
        }
        return types;
    }

    @ResponseBody
    @GetMapping("/getJoinTypes")
    public List<String> getJoinTypes() {
        List<String> types = new ArrayList<>();
        for (JoinType joinType : JoinType.values()) {
            types.add(joinType.name());
        }
        return types;
    }

    public enum DataSourceType {
        ORACLE("oracle", "oracle.jdbc.driver.OracleDriver"), MYSQL("mysql", "com.mysql.jdbc.Driver"), SQL_SERVER("microsoft:sqlserver", "com.microsoft.jdbc.sqlserver.SQLServerDriver");

        @Getter
        String type;

        @Getter
        String driver;

        DataSourceType(String type, String driver) {
            this.type = type;
            this.driver = driver;
        }
    }
}
