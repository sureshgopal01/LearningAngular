package com.itssglobal.sigma.dataintegrator.util;

/**
 * Created by Anass on 13/06/2017.
 */
public class Constants {

    public static final String JDBC = "jdbc";
    public static final String URL_SEPARATOR = "/";
    public static final String DATABASE_NAME = "DatabaseName=";
    public static final String SPACE = " ";
}
