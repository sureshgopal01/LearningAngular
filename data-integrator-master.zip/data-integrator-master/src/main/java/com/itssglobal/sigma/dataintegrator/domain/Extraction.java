package com.itssglobal.sigma.dataintegrator.domain;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.util.List;

/**
 * Created by Anass on 11/09/2017.
 */
@Data
@EqualsAndHashCode(exclude = "id", callSuper = false)
@Entity(name = "SIGMA_EXTRACTION")
@AllArgsConstructor
@NoArgsConstructor
public class Extraction extends BaseObject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @JsonIgnore
    private Long id;

    @Column(name = "name")
    private String name;

    @OneToOne
    private DataStore dataSource;

    @OneToMany(cascade = CascadeType.ALL)
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<TableExtraction> tableExtractions;
}
