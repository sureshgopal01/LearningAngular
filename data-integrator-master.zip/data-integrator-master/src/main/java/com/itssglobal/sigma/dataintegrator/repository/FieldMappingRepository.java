package com.itssglobal.sigma.dataintegrator.repository;

import com.itssglobal.sigma.dataintegrator.domain.FieldMapping;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Anass on 23/05/2017.
 */
public interface FieldMappingRepository extends JpaRepository<FieldMapping, Long> {
}
