package com.itssglobal.sigma.dataintegrator.domain;

/**
 * Created by Anass on 08/09/2017.
 */
public enum TaskTriggerPeriod {
    IMMEDIATELY, ONLY_ONCE, WEEKLY, MONTHLY, PERIODICALLY
}
