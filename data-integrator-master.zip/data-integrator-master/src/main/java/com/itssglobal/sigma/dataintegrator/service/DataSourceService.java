package com.itssglobal.sigma.dataintegrator.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itssglobal.sigma.dataintegrator.domain.DataStore;
import com.itssglobal.sigma.dataintegrator.pojo.ColumnMetadata;
import com.itssglobal.sigma.dataintegrator.pojo.DataSourceMetadata;
import com.itssglobal.sigma.dataintegrator.pojo.TableMetadata;
import com.itssglobal.sigma.dataintegrator.repository.DataStoreRepository;
import com.itssglobal.sigma.dataintegrator.util.Constants;
import org.json.JSONException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceBuilder;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Anass on 14/06/2017.
 */
@Service
public class DataSourceService {

    public static final String[] types = {"TABLE"};

    @Autowired
    @Qualifier("DataSourceMetadataCache")
    private ConcurrentHashMap<Long, DataSourceMetadata> tableMetadataByName;

    @Autowired
    private ObjectMapper objectMapper;

    private DataSourceBuilder dataSourceBuilder;
    private javax.sql.DataSource dwhDatasource;

    @Autowired
    private DataStoreRepository dataStoreRepository;

    public static String getDataSourceURL(DataStore dataStore) {
        StringBuilder appender = new StringBuilder();
        appender.append(Constants.JDBC);
        appender.append(":");
        System.out.println("SURESH:: dataStore.getDataSourceType().getType() = " + dataStore.getDataSourceType().getType());
        appender.append(dataStore.getDataSourceType().getType());
        appender.append(":");
        switch (dataStore.getDataSourceType()) {
            case ORACLE:
                appender.append("thin:@");
                appender.append(dataStore.getUrl());
                appender.append(":");
                appender.append(dataStore.getDefaultPort());
                appender.append(":");
                appender.append(dataStore.getName());
                break;
            case MYSQL:
                appender.append(Constants.URL_SEPARATOR);
                appender.append(Constants.URL_SEPARATOR);
                appender.append(dataStore.getUrl());
                appender.append(":");
                appender.append(dataStore.getDefaultPort());
                appender.append(Constants.URL_SEPARATOR);
                appender.append(dataStore.getName());
                break;
            case SQL_SERVER:
                appender.append(Constants.URL_SEPARATOR);
                appender.append(Constants.URL_SEPARATOR);
                appender.append(dataStore.getUrl());
                appender.append(":");
                appender.append(dataStore.getDefaultPort());
                appender.append(";");
                appender.append(Constants.DATABASE_NAME);
                appender.append(dataStore.getName());
        }
        System.out.println("appender = " + appender);
        return appender.toString();
    }

    public ObjectNode getAllSources() {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        ArrayNode arrayNode = objectMapper.createArrayNode();
        for (DataStore dataStore : dataStoreRepository.findAll()) {
            ArrayNode dataSourceObject = objectMapper.createArrayNode();
            dataSourceObject.add(dataStore.getId());
            dataSourceObject.add(dataStore.getName());
            dataSourceObject.add(dataStore.getUrl());
            dataSourceObject.add(dataStore.getDefaultPort());
//            dataSourceObject.add(dataStore.getDataSourceType().name());
//            dataSourceObject.add(dataStore.getId());
            arrayNode.add(dataSourceObject);
        }
        jsonObject.put("dataSources", arrayNode);
        return jsonObject;
    }

    public ObjectNode getAllDataSources() {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        ArrayNode arrayNode = objectMapper.createArrayNode();
        for (DataStore dataStore : dataStoreRepository.findAll()) {
            ObjectNode dataSourceObject = objectMapper.createObjectNode();
            dataSourceObject.put("id", dataStore.getId());
            dataSourceObject.put("name", dataStore.getName());
            dataSourceObject.put("url", dataStore.getUrl());
            dataSourceObject.put("username", dataStore.getUsername());
            dataSourceObject.put("password", dataStore.getPassword());
            dataSourceObject.put("defaultPort", dataStore.getDefaultPort());
            dataSourceObject.put("dataSourceType", dataStore.getDataSourceType().name());
            arrayNode.add(dataSourceObject);
        }
        jsonObject.put("dataSources", arrayNode);
        return jsonObject;
    }

    public ObjectNode testDatabaseConnection(DataStore dataStore) throws JSONException {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        System.out.println("DataSource object = " + dataStore);
        if (dataStoreRepository.findDataStoreByName(dataStore.getName()) != null)
            jsonObject.put("failure", "This Database is already saved !");
        else {
            try {
            	System.out.println("MYSQL:=" + dataStore.getDataSourceType().getDriver());
                Class.forName(dataStore.getDataSourceType().getDriver());
                Connection conn = DriverManager.getConnection(getDataSourceURL(dataStore), dataStore.getUsername(), dataStore.getPassword());
                if (conn.isValid(0)) {
                    jsonObject.put("success", "All good");
                } else {
                    jsonObject.put("failure", "Can not get connection !");
                }
            } catch (SQLException se) {
                se.printStackTrace();
                jsonObject.put("failure", "Verify your database information !");
            } catch (Exception e) {
                e.printStackTrace();
                jsonObject.put("failure", e.getMessage());
            }
        }
//            jsonObject.put("success", "All good");
        return jsonObject;
    }

    public Collection<TableMetadata> getTablesMetadata(DataStore dataStore) {
        if (tableMetadataByName.get(dataStore.getId()) != null) {
            return tableMetadataByName.get(dataStore.getId()).getTableMetadata();
        } else {
            List<TableMetadata> tablesMetadata = new ArrayList<>();
            dataSourceBuilder = DataSourceBuilder.create()
                    .url(getDataSourceURL(dataStore))
                    .username(dataStore.getUsername())
                    .password(dataStore.getPassword())
                    .driverClassName(dataStore.getDataSourceType().getDriver());
            dwhDatasource = dataSourceBuilder.build();
            try (Connection conn = dwhDatasource.getConnection()) {
                DatabaseMetaData dbMetadata = conn.getMetaData();
                String catalog = conn.getCatalog();
                ResultSet resTables = dbMetadata.getTables(conn.getCatalog(), null, "%", types);
                while (resTables.next()) {
                    TableMetadata.Builder builder = TableMetadata.newBuilder()
                            .withName(resTables.getString(3))
                            .withSchema(resTables.getString(2));
                    ResultSet columns = dbMetadata.getColumns(null, null,
                            resTables.getString(3), null);
                    ResultSet primaryKeys = dbMetadata.getPrimaryKeys(catalog, null, resTables.getString(3));
                    ResultSet getColumnInfo = dbMetadata.getIndexInfo(catalog, null, resTables.getString(3), true, false);
                    while (columns.next()) {
                        builder.withColumn(columns.getString(4), columns.getString(6),
                                primaryKeys.next() && primaryKeys.getString(4).equals(columns.getString(4)),
                                getColumnInfo.next() && getColumnInfo.getRow() != 0,
                                columns.getInt("NULLABLE") == DatabaseMetaData.columnNullable,
                                getColumnInfo.next() && getColumnInfo.getString("INDEX_NAME") != null);
                    }
                    TableMetadata tableMetadata = builder.build();
                    tablesMetadata.add(tableMetadata);
                }
                tableMetadataByName.putIfAbsent(dataStore.getId(), new DataSourceMetadata(dataStore.getId(), tablesMetadata));
                return tablesMetadata;
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public Collection<ColumnMetadata> getColumnsForTable(DataStore dataStore, String tableName) {
        if (tableMetadataByName.get(dataStore.getId()) != null) {
            for (TableMetadata tableMetadata : tableMetadataByName.get(dataStore.getId()).getTableMetadata()) {
                if (tableMetadata.getName().equals(tableName))
                    return tableMetadata.getColumns();
            }
            return null;
        } else
            return null;
    }

    public ObjectNode removeDataSource(Long id) {
        ObjectNode jsonObject = objectMapper.createObjectNode();
        try {
            dataStoreRepository.delete(id);
            jsonObject.put("success", "Your data source is removed !");
        } catch (Exception e) {
            jsonObject.put("failure", "You can't delete this data source ! Please remove all extractions associated with this data source before !");
        }
        return jsonObject;
    }
    
    public List<DataStore> getAllDataSources1() {

        return dataStoreRepository.findAll();
    }
}
