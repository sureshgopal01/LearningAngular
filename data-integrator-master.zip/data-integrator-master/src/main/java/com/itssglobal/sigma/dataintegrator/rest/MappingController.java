package com.itssglobal.sigma.dataintegrator.rest;

import com.fasterxml.jackson.databind.node.ObjectNode;
import com.itssglobal.sigma.dataintegrator.config.jms.JMSProperties;
import com.itssglobal.sigma.dataintegrator.domain.Extraction;
import com.itssglobal.sigma.dataintegrator.domain.TableExtraction;
import com.itssglobal.sigma.dataintegrator.domain.TaskScheduler;
import com.itssglobal.sigma.dataintegrator.jms.ExtractionSender;
import com.itssglobal.sigma.dataintegrator.repository.ExtractionRepository;
import com.itssglobal.sigma.dataintegrator.repository.TableExtractionRepository;
import com.itssglobal.sigma.dataintegrator.service.MappingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.transaction.Transactional;
import java.time.ZonedDateTime;

/**
 * Created by Anass on 15/06/2017.
 */
@Controller
@RequestMapping(value = "/api/v1/extraction")
public class MappingController {

    @Autowired
    private JMSProperties props;

    @Autowired
    private ExtractionSender extractionSender;

    @Autowired
    private TableExtractionRepository tableExtractionRepository;

    @Autowired
    private MappingService mappingService;

    @Autowired
    private ExtractionRepository extractionRepository;

    @PostMapping("/saveExtraction")
    @Transactional
    @ResponseBody
    public void saveAndSendExtraction(@RequestBody Extraction extraction) {
//        for (TableExtraction tableExtraction : extraction.getTableExtractions()) {
//            tableExtractionRepository.save(tableExtraction);
//            extractionSender.sendExtraction(props.getTaskExtractionInboundQueue(), tableExtraction);
//        }
        extractionRepository.save(extraction);
    }

    @PostMapping("/editExtraction")
    @Transactional
    @ResponseBody
    public void editAndSendExtraction(@RequestParam Long id, @RequestBody TableExtraction editedTableExtraction) {
        TableExtraction tableExtraction = tableExtractionRepository.findOne(id);
        tableExtraction.setTableName(editedTableExtraction.getTableName());
        tableExtraction.setMappingList(editedTableExtraction.getMappingList());
        tableExtraction.setJoins(editedTableExtraction.getJoins());
        tableExtraction.setFilters(editedTableExtraction.getFilters());
        tableExtraction.setCreate_table(editedTableExtraction.isCreate_table());
        tableExtraction.setImportOption(editedTableExtraction.getImportOption());
        tableExtraction.setLastModifiedDate(ZonedDateTime.now());
        tableExtractionRepository.save(tableExtraction);
        //TODO : UPDATE EXTRACTION NAME
//        extractionSender.sendExtraction(props.getTaskExtractionInboundQueue(), tableExtraction);
    }

    @GetMapping("/")
    public String createPage() {
        return "extraction/createExtraction";
    }

    @GetMapping("/getAllExtractions")
    @ResponseBody
    public ObjectNode getAllExtractions() {
        return mappingService.getAllExtractions();
    }

    @GetMapping("/getExtractionById")
    @ResponseBody
    public TableExtraction getExtractionById(@RequestParam Long id) {
        return tableExtractionRepository.findOne(id);
    }

    @GetMapping("/list")
    public String returnAllSources(Model model) {
        model.addAllAttributes(tableExtractionRepository.findAll());
        return "extraction/extractions";
    }

    @PostMapping("/deleteExtraction")
    public String deleteExtraction(@RequestParam Long id) {
        tableExtractionRepository.delete(id);
        return "extraction/extractions";
    }

    @GetMapping("/getAllTaskTriggerPeriods")
    @ResponseBody
    public ObjectNode getAllTaskTriggerPeriods() {
        return mappingService.getTaskTriggerPeriods();
    }

    @PostMapping("/setTaskSchedulerCron")
    @ResponseBody
    public ObjectNode setTaskSchedulerCron(@RequestParam Long id, @RequestBody TaskScheduler taskScheduler) {
        return mappingService.setTaskSchedulerCron(id, taskScheduler);
    }
}
