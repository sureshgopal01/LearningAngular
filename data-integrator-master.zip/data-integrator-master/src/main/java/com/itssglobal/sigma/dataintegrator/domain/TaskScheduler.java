package com.itssglobal.sigma.dataintegrator.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Created by Anass on 08/09/2017.
 */
@SuppressWarnings("serial")
@Entity(name = "SIGMA_CUBE_SCHEDULER")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
public class TaskScheduler extends AbstractAuditingEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    private TaskTriggerPeriod taskTriggerPeriod;

    @Column(name = "date")
    private String date;
}
