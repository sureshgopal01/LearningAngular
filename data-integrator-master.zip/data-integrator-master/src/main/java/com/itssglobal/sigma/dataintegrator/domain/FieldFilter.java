package com.itssglobal.sigma.dataintegrator.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.persistence.*;

/**
 * Created by Anass on 16/05/2017.
 */
@SuppressWarnings("serial")
@Entity(name = "SIGMA_FIELD_FILTER")
@Data
@EqualsAndHashCode(exclude = "id")
@AllArgsConstructor
@NoArgsConstructor
public class FieldFilter extends BaseObject {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(cascade = CascadeType.ALL)
    private Field field;

    @Enumerated(EnumType.STRING)
    private FilterOperator operator;

    @Column(name = "value")
    private String value;
}
