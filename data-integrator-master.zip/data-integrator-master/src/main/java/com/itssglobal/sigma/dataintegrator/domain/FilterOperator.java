package com.itssglobal.sigma.dataintegrator.domain;

import lombok.Getter;

/**
 * Created by Anass on 16/05/2017.
 */

public enum FilterOperator {
    GREATER_THAN(">"), GREATER_THAN_OR_EQUAL("=>"), LESS_THAN("<"), LESS_THAN_OR_EQUAL("=<"), EQUAL("="), NOT_EQUAL("!="), LIKE(">"), NOT_LIKE(">"), IS_NULL(">"), IS_NOT_NULL(">");

    @Getter
    String value;

    FilterOperator(String value) {
        this.value = value;
    }
}
