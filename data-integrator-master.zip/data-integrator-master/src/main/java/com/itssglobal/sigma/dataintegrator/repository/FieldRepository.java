package com.itssglobal.sigma.dataintegrator.repository;

import com.itssglobal.sigma.dataintegrator.domain.Field;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * Created by Anass on 16/05/2017.
 */
public interface FieldRepository extends JpaRepository<Field, Long> {
}
