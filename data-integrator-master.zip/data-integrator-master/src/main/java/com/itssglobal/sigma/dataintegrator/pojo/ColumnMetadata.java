package com.itssglobal.sigma.dataintegrator.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * Created by Anass on 18/05/2017.
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ColumnMetadata {

    private String name;

    private String type;

    private boolean primaryKey;

    private boolean unique;

    private boolean nullable;

    private boolean indexed;
}
