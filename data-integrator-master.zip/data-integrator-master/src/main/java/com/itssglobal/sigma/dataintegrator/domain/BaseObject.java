package com.itssglobal.sigma.dataintegrator.domain;

import java.io.Serializable;

/**
 * Created by Anass on 13/06/2017 at 12:14.
 */
public class BaseObject implements Serializable {
}
