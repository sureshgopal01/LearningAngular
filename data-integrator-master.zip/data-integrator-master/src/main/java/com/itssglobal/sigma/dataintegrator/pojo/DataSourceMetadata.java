package com.itssglobal.sigma.dataintegrator.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Created by Anass on 15/06/2017.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class DataSourceMetadata {

    private Long id;

    private List<TableMetadata> tableMetadata;
}
