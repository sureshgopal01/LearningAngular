package com.itssglobal.sigma.dataintegrator.messaging;

import lombok.Data;

import java.io.Serializable;

/**
 * Created by mastermind on 10/06/2017 at 00:25.
 */
@Data
public class TaskInboundMessage<T> implements Serializable {

    private String id;

    private T payload;

    private String taskType;
}
