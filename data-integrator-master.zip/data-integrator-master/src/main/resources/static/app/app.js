var app = angular.module("MyApp", ['ui.router', 'ngResource', 'ngStorage']);
app.run(function ($window, $transitions) {

    $transitions.onSuccess({}, function (transition) {
        var title = transition.to().title;
        if (title) {
            if (title instanceof Function) {
                title = title.call(transition.to(), transition.params());
            }
            $window.document.title = title;
        }
    })

});

// DATA SOURCE VARS
var editDataSourceMode = false;
var dataSourceId = 0;

// EXTRACTION VARS
var editExtractionMode = false;
var extractionId = 0;

// EXTRACTIONS POSTED ARRAY
var tableExtractions = [];
var extractionName;
var extractionDataSource;