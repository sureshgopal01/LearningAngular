/**
 * Created by othmane on 24/05/2017.
 */
app.config(function ($stateProvider) {

    // $stateProvider.state('home', {
    //
    //     url: '/home',
    //     templateUrl: 'home.html',
    //     controller: 'homeController as ctrl',
    //     title: 'Home'
    //
    // });
    $stateProvider.state('tableExtraction', {

        url: '',
        templateUrl: '/api/v1/extraction/',
        controller: 'extractionController as ctrl',
        title: 'Create Extraction'

    });

    $stateProvider.state('tableExtractions', {

        url: '',
        templateUrl: '/api/v1/extraction/list',
        controller: 'extractions as ctrl',
        title: 'Extractions'

    });

    $stateProvider.state('testConnection', {

        url: '',
        templateUrl: '/api/v1/dataSource/creation',
        controller: 'testConnectionController as ctrl',
        title: 'Data source creation'

    });

    $stateProvider.state('dataSources', {

        url: '',
        templateUrl: '/api/v1/dataSource/list',
        controller: 'dataSources as ctrl',
        title: 'Data sources'

    });

});
app.config(['$compileProvider', function ($compileProvider) {
    $compileProvider.debugInfoEnabled(false);
}]);