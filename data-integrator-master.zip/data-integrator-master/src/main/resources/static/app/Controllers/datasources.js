app.controller("dataSources", function ($scope, $http, $state) {
    editDataSourceMode = false;
    editExtractionMode = false;
    extractions = [];
});

function editDataSource(id) {
    editDataSourceMode = true;
    dataSourceId = id;
    swal('Please wait');
    swal.showLoading();
    document.getElementById("testConnection").click();
}

function deleteDataSource(id) {

    var jqxhr = $.getJSON('/api/v1/dataSource/deleteDataSource?id=' + id, function () {

    })
        .done(function () {
            var response = jqxhr.responseJSON;
            if (response.success) {
                swal({
                    title: 'Successfully Deleted',
                    text: response.success,
                    type: 'success',
                    confirmButtonColor: '#3085d6',
                    confirmButtonText: 'OK',
                    confirmButtonClass: 'btn btn-success',
                    buttonsStyling: false
                });
                setTimeout(function () {
                    location.reload();
                }, 2000);
            }
            else {
                swal(
                    'Warning',
                    response.failure,
                    'warning'
                )
            }
        })
        .fail(function () {
            swal(
                'Warning',
                'Please retry !',
                'warning'
            );
            console.log("error");
        })
        .always(function () {
            console.log("complete");
        });
}