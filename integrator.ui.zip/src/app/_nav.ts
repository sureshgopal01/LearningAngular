export const navItems = [
  {
    name: 'Dashboard',
    url: '/dashboard',
    icon: 'icon-home'
  },
  {
    title: true,
    name: 'Integrator'
  },
  {
    name: 'Menu',
    url: '/base',
    icon: 'icon-star',
    children: [
      {
        name: 'Create Data Source',
        url: '/base/cards',
        icon: 'icon-star'
      },
      {
        name: 'Extraction',
        url: '/base/createextraction',
        icon: 'icon-star'
      },
      {
        name: 'Data Sources',
        url: '/base/datasources',
        icon: 'icon-star'
      },
      {
        name: 'Extractions',
        url: '/base/forms',
        icon: 'icon-star'
      },
    ]
  }
];
