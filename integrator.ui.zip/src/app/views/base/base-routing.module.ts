import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CardsComponent } from './cards.component';
//  Datasources Component
import { DatasourcesComponent } from './datasources.component';
import { CreateExtractionComponent } from './createextraction.component';

const routes: Routes = [
  {
    path: '',
    data: {
      title: 'Base'
    },
    children: [
      {
        path: 'cards',
        component: CardsComponent,
        data: {
          title: 'Cards'
        }
      },
      {
        path: 'forms',
        component: CreateExtractionComponent,
        data: {
          title: 'Forms'
        }
      },
      {
        path: 'datasources',
        component: DatasourcesComponent,
        data: {
          title: 'Datasources'
        }
      },
      {
        path: 'createextraction',
        component: CreateExtractionComponent,
        data: {
          title: 'CreateExtraction'
        }
      },
      {
        path: 'cards/:id',
        component: CardsComponent,
        data: {
          title: 'Cards'
        }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BaseRoutingModule {}
